package com.project.library.Library_Management.Student.Borrows;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;


@Service
public class BorrowedService {

	private static List<Borrow>borrow= new ArrayList<>();
	

}
